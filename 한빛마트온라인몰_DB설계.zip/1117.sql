CREATE TABLE 제조업체(
    제조업체명 VARCHAR(20) NOT NULL, 
    전화번호 VARCHAR(20),
    위치 VARCHAR(20),
    담당자 INT,
    PRIMARY KEY (제조업체명)
    
);

CREATE TABLE 회원(
    회원ID VARCHAR(20) NOT NULL,
    비밀번호 VARCHAR(20) NOT NULL,
    이름 VARCHAR(20) NOT NULL, 
    나이 INT DEFAULT NULL,
    직업 VARCHAR(20) DEFAULT NULL,
    등급 VARCHAR(20) NOT NULL DEFAULT 'SILVER',
    적립금 INT NOT NULL DEFAULT 0,
    PRIMARY KEY (회원ID),
    CHECK(나이 >= 0),
    CHECK(등급 IN('SILVER', 'GOLD', 'VIP'))

);

CREATE TABLE 상품( 
    상품번호 VARCHAR(20) NOT NULL,
    상품명 VARCHAR(50) NOT NULL,
    재고량 INT DEFAULT 0,
    제조업체명 VARCHAR(50) NOT NULL,
    공급수량 INT,
    단가 INT,
    공급량 INT,
    PRIMARY KEY (상품번호),
    FOREIGN KEY (제조업체명) REFERENCES 제조업체(제조업체명),
    CHECK (재고량 >= 0), 
    CHECK (공급수량 >= 0), 
    CHECK (단가 >= 0), 
    CHECK (공급량 >= 0) 
);

CREATE TABLE 게시글 (
    글번호 INT NOT NULL, 
    글제목 VARCHAR(100) NOT NULL, 
    글내용 TEXT NOT NULL, 
    작성일자 DATE NOT NULL DEFAULT CURRENT_DATE, 
    회원ID VARCHAR(20) NOT NULL, 
    PRIMARY KEY (글번호),
    FOREIGN KEY (회원ID) REFERENCES 회원(회원ID) 
  
);
CREATE TABLE 주문 (
    주문번호 VARCHAR(20) NOT NULL, 
    주문수량 INT NOT NULL DEFAULT 1, 
    배송지 VARCHAR(100) NOT NULL, 
    주문일자 DATE NOT NULL DEFAULT CURRENT_DATE, 
    회원ID VARCHAR(20) NOT NULL,
    상품번호 VARCHAR(20) NOT NULL,
    PRIMARY KEY (주문번호),
    FOREIGN KEY (회원ID) REFERENCES 회원(회원ID), 
    FOREIGN KEY (상품번호) REFERENCES 상품(상품번호), 
    CHECK (주문수량 >= 1) 
);




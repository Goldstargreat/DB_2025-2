CREATE TABLE 회원 (
    회원ID VARCHAR2(20) NOT NULL PRIMARY KEY,
    비밀번호 VARCHAR2(200) NOT NULL,
    성명 VARCHAR2(20) NOT NULL,
    생년월일 DATE NOT NULL,
    휴대폰번호 VARCHAR2(20) NOT NULL,
    주소 VARCHAR2(200) NOT NULL,
    등급 VARCHAR2(20) DEFAULT 'Friends' NOT NULL 
           CHECK (등급 IN ('Friends', 'Bronze', 'Silver', 'Gold', 'Platinum')),
    적립금 NUMBER DEFAULT 0 NOT NULL CHECK (적립금 >= 0)
);

CREATE TABLE 납품업체 (
    납품업체명 VARCHAR2(50) NOT NULL PRIMARY KEY,
    전화번호   VARCHAR2(20),
    위치       VARCHAR2(50),
    담당자     VARCHAR2(20)
);

CREATE TABLE 상품 (
    상품번호     VARCHAR2(20)   NOT NULL PRIMARY KEY,
    상품명       VARCHAR2(20)   NOT NULL,
    재고량       NUMBER         DEFAULT 0 NOT NULL CHECK (재고량 >= 0),
    납품업체명   VARCHAR2(50)   NOT NULL,
    납품수량     NUMBER         DEFAULT 0 NOT NULL CHECK (납품수량 >= 0),
    단가         NUMBER         DEFAULT 0 NOT NULL CHECK (단가 >= 0),
    납품일자     DATE,

    FOREIGN KEY (납품업체명) REFERENCES 납품업체(납품업체명)
);

CREATE TABLE 리뷰 (
    글번호   NUMBER       NOT NULL PRIMARY KEY,
    글제목   VARCHAR2(100) NOT NULL,
    글내용   CLOB,
    작성일자 DATE          DEFAULT SYSDATE NOT NULL,
    회원ID   VARCHAR2(20)  NOT NULL,
    
    FOREIGN KEY (회원ID) REFERENCES 회원(회원ID)
);

-- 글번호 자동 증가를 위한 시퀀스
CREATE SEQUENCE 리뷰_SEQ
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

-- 글번호 자동 입력용 트리거
CREATE OR REPLACE TRIGGER 리뷰_BI
BEFORE INSERT ON 리뷰
FOR EACH ROW
BEGIN
    :NEW.글번호 := 리뷰_SEQ.NEXTVAL;
END;
/

CREATE TABLE 주문 (
    주문번호   VARCHAR2(20)  NOT NULL PRIMARY KEY,
    주문수량   NUMBER        DEFAULT 0 NOT NULL CHECK (주문수량 >= 0),
    배송지     VARCHAR2(20)  NOT NULL,
    주문일자   DATE          DEFAULT SYSDATE NOT NULL,
    회원ID     VARCHAR2(20)  NOT NULL,
    상품번호   VARCHAR2(20)  NOT NULL,
    
    FOREIGN KEY (회원ID) REFERENCES 회원(회원ID),
    FOREIGN KEY (상품번호) REFERENCES 상품(상품번호)
); //



